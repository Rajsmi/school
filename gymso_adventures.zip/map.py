from command import Command
from item import Item
from room import Room
from inventory import Inventory

def static_comm(comm):
    """Simple function for returning transcript ids of static commands

    :param comm: string
    :return: int; ts_id
    """
    comm = comm[0]
    match comm:
        case 'help': return 507
        case 'info': return 508

def research(object):
    """Function for research command, used for observe rooms/items more in detail.

    :param object: str; object for research (room or item)
    :return: id/s with data for formatting of transcript of researched room/item
    """

    if object in Room.ar_ins.aliases or not object:
        # if researched object is room (only, if player is in the room)
        return Room.ar_ins.research()
    for item in Room.ar_ins.items:
        # if researched object is item (only, if the item is in the room and is accessible)
        if object in item.aliases:
            return item.research()
    for item in Inventory.inventory.items:
        # if researched object is item (only, if the item is in inventory)
        if object in item.aliases:
            return item.research()
    for room in Room.all_rooms:
        # if researched object is room, but not the room the player is in
        if room.name == object:
            return 204
    for item in Item.all_items:
        # if researched object is item, but is not reachable
        if item.name == object:
            return 205
    # if typed object doesn't exist
    return 206, {"object": object}

def manage_item(data):
    """Manage items depending on data sent

    :param data: list; action and item
    :return: ts_id
    """
    action = data[0]
    item = data[1]


    if action == "pickup_item":
        for inv_item in Inventory.inventory.items:
            # check if item is already in inventory
            if item in inv_item.aliases:
                return 209, {"object": inv_item.name}
        room_return = Room.ar_ins.remove_item(item)
        # if returned value is (exceptional) code with data
        if type(room_return) in [int, float, tuple]: return room_return
        Inventory.inventory.add_item(room_return)
        return 502, {"object": room_return.name}

    if action == "place_item":
        item_return = Inventory.inventory.remove_item(item)
        if type(item_return) in [int, float, tuple]: return item_return
        Room.ar_ins.add_item(item_return)
        return 503, {"object": item_return.name}

    if action == "use_item":
        item_return = Inventory.inventory.check_item(item)
        if type(item_return) in [int, float, tuple]: return item_return


        if Room.ar_ins.name in item_return.usable_in:
            for ret_item in item_return.usable_with:
                if ret_item in Inventory.inventory.items:
                    return story_creator(item_return.name)
            else:
                if not item_return.usable_with:
                    return story_creator(item_return.name)
                if item_return.ts_usable: return float(f'{item_return.desc_id}.9')
                return 212
        else:
            return 211

def story_creator(use_action):
    """Unique story scenes in game

    :param use_action: str; item
    :return: ts_id
    """
    match use_action:
        case 'pisemka' | 'propiska':
            Inventory.inventory.remove_item('pisemka')
            Inventory.inventory.remove_item('propiska')
            return 305, 1.1, 305.1, 1.2, 998

        case 'prezuvky':
            Inventory.inventory.remove_item('prezuvky')
            acko = Room.check_room('acko')
            acko.is_locked = False
            return 306

        case 'isic':
            isic = Inventory.inventory.check_item('isic')
            isic.usable_in = []
            polevka = Item.check_item('polevka')
            Inventory.inventory.add_item(polevka)
            return 307, 1.1, 502, {"object": polevka.name}

        case 'polevka' | 'petakova':
            klice = Item.check_item('klice')
            if klice.hidden: return 212
            Inventory.inventory.remove_item('polevka')
            petakova = Item.check_item('petakova')
            petakova.usable_in, petakova.usable_with = [], []
            klice.available = True
            pickup = manage_item(('pickup_item', 'klice'))
            return (308, 1.1) + pickup

        case 'klice':
            kabinet = Room.check_room('kabinet')
            kabinet.is_locked = False
            Inventory.inventory.remove_item('klice')
            Room.change_room('kabinet')
            return 309

        case 'dvoutisicovka':
            Inventory.inventory.remove_item('dvoutisicovka')
            if Room.actual_room == 'bufet': return 310
            if Room.actual_room == 'sekretariat': return 311, 1.2, 999


def save_variables():
    """Save all game variables for saving the game

    :return: list; list containing all game data
    """
    ALL_ROOMS = [dict(room.__dict__) for room in Room.all_rooms]
    ALL_ITEMS = [dict(item.__dict__) for item in Item.all_items]
    AR_INS = dict(Room.ar_ins.__dict__)
    INVENTORY = dict(Inventory.inventory.__dict__)

    for room in ALL_ROOMS:
        temp_rooms = []
        temp_items = []
        for rroom in room["reachable_rooms"]:
            temp_rooms.append(rroom.name)
        for ritem in room["items"]:
            temp_items.append(ritem.name)

        room["items"] = temp_items
        room["reachable_rooms"] = temp_rooms

    for room in ALL_ROOMS:
        if room["name"] == Room.actual_room:
            AR_INS = room

    for item in ALL_ITEMS:
        temp_items = []
        for uitem in item["usable_with"]:
            temp_items.append(uitem.name)
        item["usable_with"] = temp_items

    temp_inv_items = []
    for item in INVENTORY["items"]:
        temp_inv_items.append(item.name)
    INVENTORY["items"] = temp_inv_items

    data = {
        "actual_room": Room.actual_room,
        "ar_ins": AR_INS,
        "all_rooms": ALL_ROOMS,
        "all_items": ALL_ITEMS,
        "inventory": INVENTORY
    }
    return data

def load_variables(data):
    """Loads all game data from external function

    :param data: list; list containing all game data
    :return: None
    """
    for room in data["all_rooms"]:
        Room(room["name"], room["desc_id"], displayed=room["displayed"], aliases=room["aliases"], is_locked=room["is_locked"],
             reachable_rooms=room["reachable_rooms"], items=room["items"], ts_locked=room["ts_locked"])
    Room.actual_room = data["actual_room"]
    Room.ar_ins = [room for room in Room.all_rooms if room.name == Room.actual_room][0]
    for item in data["all_items"]:
        Item(item["name"], item["desc_id"], available=item["available"], hidden=item["hidden"], predefined=item["predefined"], static=item["static"],
             aliases=item["aliases"], usable_in=item["usable_in"], usable_with=item["usable_with"], ts_available=item["ts_available"], ts_usable=["ts_usable"])
    inv = Inventory(items=data["inventory"]["items"])

    for item in Item.all_items:
        for inv_item in inv.items:
            if item.name == inv_item:
                inv.items.append(item)
                inv.items.remove(inv_item)

    Inventory.inventory = inv

    item_to_room_compiler()
    set_commands()


def item_to_room_compiler():
    """Replaces strings of items in items of Room instances with equivalent item object

    :return: None
    """
    for room in Room.all_rooms:
        for item in Item.all_items:
            if item.name in room.items:
                room.items.remove(item.name)
                room.items.append(item)


def default_game():
    """Load default game data

    :return: None
    """
    # CREATING INVENTORY
    inventory = Inventory(items=[Item('isic', 702, predefined=True, usable_in=['bufet'])])

    # CREATING ROOMS
    Room('c203', 618, reachable_rooms=['schody'], items=['propiska'])
    Room('vestibul', 610, reachable_rooms=['satna', 'acko', 'becko', 'schody'], items=['zrcadlo'])
    Room('satna', 611, reachable_rooms=['vestibul'], items=['prezuvky'])
    Room('acko', 613, reachable_rooms=['vestibul', 'sekretariat'], is_locked=True, ts_locked=True)
    Room('becko', 614, reachable_rooms=['vestibul', 'knihovna', 'bufet', 'studovna'])
    Room('bufet', 621, reachable_rooms=['becko'], items=['klice'])
    Room('knihovna', 615, reachable_rooms=['becko'], items=['petakova'])
    Room('studovna', 616, reachable_rooms=['becko'], items=['dvoutisicovka'])
    Room('schody', 619, reachable_rooms=['c203', 'kabinet', 'vestibul'])
    Room('kabinet', 620, reachable_rooms=['schody'], is_locked=True, items=['pisemka'])
    Room('sekretariat', 622, reachable_rooms=['acko'])

    # CREATING ITEMS
    Item('propiska', 704, hidden=True, predefined=True, usable_in=['kabinet'], usable_with=['pisemka'])
    Item('zrcadlo', 703, hidden=True, static=True)
    Item('klice', 705, hidden=True, predefined=True, available=False, ts_available=True, usable_in=['schody'])
    Item('pisemka', 706, hidden=True, predefined=True, usable_in=['kabinet'], usable_with=['propiska'], ts_usable=True)
    Item('petakova', 707, predefined=True, usable_in=['bufet'], usable_with=['polevka'])
    Item('prezuvky', 708, predefined=True, usable_in=['satna'])
    Item('dvoutisicovka', 709, hidden=True, predefined=True, usable_in=['bufet', 'sekretariat'])
    Item('polevka', 710, predefined=True, usable_in=['bufet'], usable_with=['petakova'], ts_usable=True)

    item_to_room_compiler()
    set_commands()

def set_commands():
    """Loads all commands used in the game

    :return: None
    """
    # CREATING COMMANDS
    Command('go', Room.change_room, aliases=["jit", "jdi"], tags=["args_required"])
    Command('research', research, aliases=["prozkoumej", "pro", "prozkoumat"], tags=["args_optional", "limited"])
    [Command(room.name, Room.change_room, aliases=[room.name, room.name[:3]]) for room in Room.all_rooms]
    Command('inventory', Inventory.inventory.show_inventory, aliases=["i", "inv", "inventar"])
    Command('pickup_item', manage_item, aliases=["seber", "vezmi", "seb", "vem"], tags=["full_command", "args_required", "limited"])
    Command('place_item', manage_item, aliases=["poloz", "pol"], tags=["full_command", "args_required", "limited"])
    Command('STATIC_get_room_desc', Room.ar_ins.get_description, aliases=["static_get_room_desc"], tags=["border"])
    Command('get_directions', Room.ar_ins.get_directions, aliases=["kam"], tags=["static", "limited"])
    Command('use_item', manage_item, aliases=['použij', 'pou'], tags=["args_required", "full_command", "limited"])
    Command('save', save_variables, aliases=['sav', 'uloz', 'ulo'], tags=["static", "save"])
    Command('help', static_comm, aliases=['nav', 'navod', 'help', 'hel'], tags=["full_command"])
    Command('info', static_comm, aliases=['info'], tags=["full_command"])


