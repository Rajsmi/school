class Command:
    all_commands = []

    def __init__(self, name: str, action, *, aliases=None, tags=None):
        if tags is None:
            tags = []
        if aliases is None:
            aliases = [name]

        self.name = name
        self.action = action
        self.aliases = aliases
        self.tags = tags

        Command.all_commands.append(self)
