class Room:
    actual_room = 'c203'
    all_rooms = []
    ar_ins = []

    def __init__(self, name: str, description: int, *, is_locked=False, reachable_rooms=None, items=None, displayed=None,
                 aliases=None, ts_locked=False):
        if aliases is None:
            aliases = []
        if items is None:
            items = []
        if reachable_rooms is None:
            reachable_rooms = []
        if displayed is None:
            displayed = name

        self.name = name
        self.desc_id = description
        self.displayed = displayed  # displayed name of the room TODO: dodělat zobrazování správného názvu místnosti
        self.aliases = [name, name[:3]] + aliases
        self.is_locked = is_locked
        self.reachable_rooms = reachable_rooms
        self.items = items # only names of items, not objects
        self.ts_locked = ts_locked

        Room.all_rooms.append(self)

        # replaces names of rooms with instance of this class
        for room in Room.all_rooms:
            for rroom in Room.all_rooms:
                if room.name in rroom.reachable_rooms:
                    rroom.reachable_rooms.remove(room.name)
                    rroom.reachable_rooms.append(room)

        Room.ar_ins = [room for room in Room.all_rooms if room.name == Room.actual_room][0]

    @classmethod
    def change_room(cls, room: str):
        ar_index = ''
        comm_room_index = ''

        for index, value in enumerate(cls.all_rooms):
            if value.name == cls.actual_room:
                ar_index = index
            if room in value.aliases:
                comm_room_index = index

        if room in cls.ar_ins.aliases:
            return 101, {"room": cls.ar_ins.name}

        r_rooms = cls.all_rooms[ar_index].reachable_rooms

        for x in range(len(r_rooms)):
            go_room = cls.all_rooms[comm_room_index]

            if room in cls.all_rooms[ar_index].reachable_rooms[x].aliases:
                if go_room.is_locked:
                    if go_room.ts_locked:
                        return float(f'{go_room.desc_id}.9')
                    return 103

                cls.actual_room = cls.all_rooms[comm_room_index].name
                cls.ar_ins = cls.all_rooms[comm_room_index]
                # return 104, cls.all_rooms[comm_room_index].desc_id, {"room": cls.actual_room}
                return 104, {"room": cls.actual_room}
        for x in range(len(r_rooms)):
            if room not in cls.all_rooms[ar_index].reachable_rooms[x].aliases:
                reachable_str = ", ".join([r_string.name for r_string in r_rooms])
                return 102, {"room": room, "r_rooms": reachable_str}

    @classmethod
    def get_description(cls, _):
        item_string = "\n".join([f" ◦ {item.name}" for item in cls.ar_ins.items if not item.hidden and item.predefined])
        return cls.ar_ins.desc_id, 1, {"string": f'\n\nJe tu:\n{item_string}' if item_string else ''}

    @classmethod
    def get_directions(cls):
        reachable_str = ", ".join(r_string.name for r_string in cls.ar_ins.reachable_rooms)
        return 105, {"r_rooms": reachable_str}

    @classmethod
    def check_room(cls, room_name):
        for room in cls.all_rooms:
            if room_name in room.aliases:
                return room
        else:
            return 201

    def research(self):
        for item in self.items: item.hidden = False
        return float(f'{self.desc_id}.1')


    def add_item(self, item):
        self.items.append(item)

    # alias for pickup_item
    def remove_item(self, item_name):
        for item in self.items:
            if item_name in item.aliases:
                if item.hidden:
                    return 205
                if not item.available:
                    if item.ts_available: return float(f'{item.desc_id}.9')
                    return 207
                if item.static:
                    return 208
                self.items.remove(item)
                return item
        else:
            for room in Room.all_rooms:
                for item in room.items:
                    if item_name in item.aliases:
                        return 205
            return 206, {"object": item_name}
