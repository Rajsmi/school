class Inventory():
    all_inventories = []
    inventory = None

    def __init__(self, items=None):
        if items is None:
            items = []
        self.items = items

        Inventory.all_inventories.append(self)
        Inventory.inventory = Inventory.all_inventories[0]
        if len(Inventory.all_inventories) > 1: raise Exception("Ve hře je více než 1 inventář! Pro hru je potřeba pouze jeden.")

    def show_inventory(self, _):
        if not self.items: return 501
        inv_string = "\n".join([f"# {item.name}" for item in self.items])
        return 504, 1, {"string": "\n" + inv_string}

    def add_item(self, item):
        self.items.append(item)

    def remove_item(self, item_name):
        for item in self.items:
            if item_name in item.aliases:
                self.items.remove(item)
                return item
        else:
            return 210

    def check_item(self, item_name):
        for item in self.items:
            if item_name in item.aliases:
                return item
        else:
            return 210

