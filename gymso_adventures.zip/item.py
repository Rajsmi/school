class Item:
    all_items = []

    def __init__(self, name, desc_id, *, available=True, hidden=False, predefined=False, static=False, aliases=None,
                 usable_in=None, usable_with=None, ts_available=False, ts_usable=False):
        if usable_with is None:
            usable_with = []
        if usable_in is None:
            usable_in = []
        if aliases is None:
            aliases = []
        self.name = name
        self.desc_id = desc_id
        self.aliases = [name, name[:3]] + aliases
        self.available = available  # if item is accessible, can be used/researched
        self.ts_available = ts_available # if unique transcript exists for item available exception
        self.ts_usable = ts_usable # if unique transcript exists for item usable exception
        self.hidden = hidden # if item is shown
        self.predefined = predefined  # if item is used in room description
        self.static = static  # if item is relocatable
        self.usable_in = usable_in
        self.usable_with = usable_with

        Item.all_items.append(self)

        for item in Item.all_items:
            for uitem in Item.all_items:
                if item.name in uitem.usable_with:
                    uitem.usable_with.remove(item.name)
                    uitem.usable_with.append(item)

    @classmethod
    def check_item(cls, item_name):
        for item in cls.all_items:
            if item_name in item.aliases:
                return item
        else:
            return 205


    def research(self):
        if self.hidden: return 205
        return self.desc_id




