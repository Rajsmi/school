from gamefc import command_handler, clear_console, main_menu, lprint, fprint

end_game = 'konec'
is_running = True


def game():


    mmenu = False
    while not mmenu:

        fprint("Vyber jednu možnost:\n [1] Nová hra\n [2] Načíst hru\n [3] Konec", cmd_time=.15)
        start_input = input("--> ")
        mmenu = main_menu(start_input)

    if mmenu == 'end': return
    clear_console()


    while is_running:
        command_handler('STATIC_get_room_desc')
        user_input = input('--> ')
        clear_console()
        # os.system('cls')
        if user_input == end_game: break
        clb = command_handler(user_input)
        if clb == 'end': break




if __name__ == '__main__':
    game()

