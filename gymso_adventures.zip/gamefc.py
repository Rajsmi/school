import json
import random
import time

from command import Command
import map


with open('text_script.json', encoding='utf-8') as f:
    f = json.load(f)
    TSCRIPT = {}
    for catg in f:
        for code in f[catg]:
            TSCRIPT[float(code.split('#')[0])] = f[catg][code]




# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=GAME HANDLING=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
def command_handler(user_command):
    """Handles the command passed within this function.

    :param user_command: str; command sent by user
    :return: None
    """
    user_command = user_command.strip().lower().split()

    for comm in Command.all_commands:
        if not user_command: break

        rules = [
            user_command[0] in comm.aliases,
            len(user_command) > 1 if "args_required" in comm.tags else True,
        ]

        if all(rules):
            RIDS = [1, 504] # returned ids
            data_sent = None
            tout = None

            if "border" in comm.tags: tout="border"
            elif "limited" in comm.tags: tout="limited"

            if "static" in comm.tags:
                # if command is tagged as static command (e.g. help command, author command etc.)
                if "save" in comm.tags: return save_game(comm.action())
                get_tscript(comm.action(), view=tout)
                return
            if "return_none" in comm.tags:
                # if command is tagged as return_none command
                get_tscript(comm.action(None), view=tout)
                return
            if "full_command" in comm.tags:
                # if command is tagged as full_command
                user_command[0] = comm.name
                returned_value = comm.action(user_command)
                get_tscript(returned_value, view=tout)
                if type(returned_value) == tuple:
                    if 998 in returned_value or 999 in returned_value:
                        time.sleep(3)
                        return 'end'
                return


            if len(user_command) == 1:
                # if command is shorthand for more-words commands (handler command is argument at the same time)
                data_sent = comm.name
                if "args_optional" in comm.tags:
                    data_sent = None
            if len(user_command) > 1:
                # if command is composed of handler command and arguments, is sending only arguments
                user_command.pop(0)
                data_sent = user_command[0]

            # runs function assigned to command with return value of tuple of ids (ints) and data (dict)
            run = comm.action(data_sent)
            if type(run) is int: run = (run,)
            return get_tscript(run, view=tout)


        if rules[0]:
            # if command requires argument/s
            get_tscript((202, {"command": user_command[0]}))
            break

    else:
        # not existing command
        get_tscript(203)


def main_menu(num):
    try:
        num = int(num)
    except:
        print('Zadej číselnou hodnotu!')
        return False


    match num:
        case 1:
            new_game()
            lprint("""
               _______     ____  __  _____  ____             _______      ________ _   _ _______ _    _ _____  ______  _____ 
              / ____\ \   / /  \/  |/ ____|/ __ \      /\   |  __ \ \    / /  ____| \ | |__   __| |  | |  __ \|  ____|/ ____|
             | |  __ \ \_/ /| \  / | (___ | |  | |    /  \  | |  | \ \  / /| |__  |  \| |  | |  | |  | | |__) | |__  | (___  
             | | |_ | \   / | |\/| |\___ \| |  | |   / /\ \ | |  | |\ \/ / |  __| | . ` |  | |  | |  | |  _  /|  __|  \___ \ 
             | |__| |  | |  | |  | |____) | |__| |  / ____ \| |__| | \  /  | |____| |\  |  | |  | |__| | | \ \| |____ ____) |
              \_____|  |_|  |_|  |_|_____/ \____/  /_/    \_\_____/   \/   |______|_| \_|  |_|   \____/|_|  \_\______|_____/ \n\n""",
                   10000)
            time.sleep(1)
            fprint(
                "*Hodně nepříjemné zvuky školního zvonku*\nJsi na gymplu. Zrovna ti skončila hodina matematiky s Michalikovou, kde jste psali test. "
                "Z toho testu potřebuješ alespoň dvojku, abys měl vyznamenání a tohle byl poslední test.", limit=80)
            time.sleep(10)
            fprint(
                "Jenže co se nedozvíš! Z pěti příkladů sis byl jistý, že jen jeden máš špatně, což by ti dvojku zaručilo. Ale v dalším příkladě "
                "všichni spolužáci mluví o nějaké změně znaménka, na kterou jsi zapomněl! A protože to vyznamenání na vysvědčení prostě chceš,"
                "tak se vydáváš na velmi riskatní gympláckou misi.", limit=80)
            time.sleep(10)
            fprint(
                "Víš, že učitelka Michaliková si je odnesla do kabinetu, takže se tam musíš dostat. A tak si vydáváš do útrob gymplu.", limit=80)
            time.sleep(5)
            fprint('POZNÁMKA AUTORA: S poctivostí nejdál dojdeš, a to i tady. Pro nápovědu napiš "nav"')
            return True
        case 2:
            load_game()
            return True
        case 3:
            return 'end'

def new_game():
    map.default_game()

def save_game(data):
    with open('save.json', 'w') as save_file:
        json.dump(data, save_file)
    print('Hra byla uložena')

def load_game():
    with open('save.json', 'r') as save_file:
        data = json.load(save_file)
        map.load_variables(data)

# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# -=-=-=-=-=-=-=-=-=-=-=TEXT PRINTING, FORMATTING=-=-=-=-=-=-=-=-=-=-=-
# -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

def get_tscript(data: int | float | tuple, *, fixed=False, pos=0, view=None):
    """Text generator. Prints random or specified transcript in specified key.

    :param data: int | tuple; key of specified transcript
    :param fixed: bool, optional default=False; exactly specify transcript
    :param pos: int, optional default=None; index of specified transcript
    :param view: ; type of text formatting
    :return: None
    """

    # initialing value of tsc_id variable
    if data is None:
        id = 201

    if type(data) in (int, float):
        data = (data,)

    tid = [id for id in data if type(id) in (int, float)]
    ftext = data[-1] if type(data[-1]) is dict else {}

    show = print
    if view == 'border': show = fprint
    if view == 'limited': show = lprint


    id = data[0]
    if id == 0: return


    if fixed:
        show(TSCRIPT[id][pos])
        return


    tscript = "".join([(random.choice(TSCRIPT[x])).format_map(ftext) for x in tid])
    show(tscript)

def clear_console():
    """Add 15 new lines in console. ("Clears" the console)

    :return: None
    """
    print('\n' * 5)


def fprint(text: str, limit=50, *, view=None, cmd_time=.25):
    vs = '║'  # vertical
    hs = '='  # horizontal
    cs = '*'  # corner
    limit = limit
    cmd_time = cmd_time

    raw_lines = text.split("\n")

    line = []
    lines = []

    for one_line in raw_lines:
        for word in one_line.split(" "):
            if len(word) > limit: raise Exception(
                f"fprint: Limit počtu znaků na řádku je {limit}, v textu se však vyskytuje slovo o počtu znaků {len(word)}.")
            string = " ".join(line)

            if len(string + f' {word}') <= limit:
                line.append(word)
            else:
                lines.append(string)
                line = []
                line.append(word)
        else:
            lines.append(" ".join(line))

        line = []

    if view == 'limited':
        for one_line in lines:
            print(one_line)
            time.sleep(cmd_time)

    else:
        print(cs + hs * limit + cs)
        time.sleep(cmd_time)
        for line_str in lines:
            fstr = "{}{}{:>" + str(limit - len(line_str) + 1) + "}"
            print(fstr.format(vs, line_str, vs))
            time.sleep(cmd_time)
        print(cs + hs * limit + cs)

def lprint(text: str, limit=50):
    fprint(text, view='limited', limit=limit)
